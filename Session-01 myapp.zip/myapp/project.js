var fs  = require('fs')

//create function to save data to file

function saveData(data){

                fs.appendFile("server-data.json",data,(er)=>{
                    if(er)
                        throw er;
                    console.log('data is saved');
                })
}

function add(a,b){
    var c =a+b;
    console.log(c);
    saveData("sum of two numbers"+c);
}

function mul(a,b){
    var c =a*b;
    console.log(c);
    saveData("mul of two numebrs"+c);
}

///call to function 
add(101,14)
mul(404,15)

