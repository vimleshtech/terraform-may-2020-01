/* function: is set of command or statement which can be reused */

//funciton : no argument no return 
function welcome(){

    console.log('welcome to function world !!!!')
    console.log('we are learning about project automation ')
}
//or
wel=()=>{
    console.log('welcome to function world !!!!')
}
//function with argument
function add (a,b){
    var c =a+b;
    console.log(c);
}
//function with argument and return 
function mul(n1,n2){
    return n1*n2;
}
//call to funciton 
welcome()
welcome()
wel()
add(333,555)
add(66,77)

//
var n = mul(11,33)
console.log(n)


