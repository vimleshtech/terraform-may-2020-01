// comment  : single line comment 

/*
multiple comment 
.....................
-----------------------
*/

//declaration of variables 
var a =11 //var is keyword, a variable , 11 is value or data
var b =455

console.log(a)
console.log(b)

//expression 
var c =a+b
console.log(c)

/*
data type:
 number
 string
 boolean
 object: array
 object : json
 function 
*/

// number
var num =33566
console.log(typeof num)
var num =33566.555
console.log(typeof num)



//string 
var s="hey, this is test code"
console.log(typeof s)

var a ='hi,test'
console.log(typeof a)


//boolean
var isProd=true 
console.log(typeof isProd)

//object: array (collection of data or values)
var data=[111,434,,6,33,66,'fff']  //index start from 0
console.log(typeof data)
console.log(data)
console.log(data[1]) //print 2nd value 



//json 
var users = {name:'nitin',age:34,salary:4444}
console.log(users);

var conf={
            host:'192.1.1.2',
            user:'testuser',
            password:'ec2',
            port:3304
        }

console.log(conf)























 
