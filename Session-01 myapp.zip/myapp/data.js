
//import library 

var fs = require('fs'); //file system 

fs.writeFile("server-data.json",
            "{name:'webserver',user:'user',password:'pwd'}",
            (err)=>{


                    if(err){
                        throw err
                    }else{

                        console.log('data is saved')
                    }
    });









