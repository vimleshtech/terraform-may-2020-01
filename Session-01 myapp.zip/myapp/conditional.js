
var isprod=false 

if(isprod){

    console.log('production environment')
}else{
    console.log('dev or test environment')

}
